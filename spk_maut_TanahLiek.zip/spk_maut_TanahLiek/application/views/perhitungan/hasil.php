<?php $this->load->view('layouts/header_admin'); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-fw fa-chart-area"></i> Data Hasil Akhir</h1>
	<button type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModal">
		<i class="fa fa-print"></i> 
  Cetak Laporan
</button>
	<!-- <a href="<?= base_url('Perhitungan/hasil_cetak'); ?>" class="btn btn-primary"> <i class="fa fa-print"></i> Cetak Data </a> -->
</div>

<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cetak Laporan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
	  			<form action="hasil_cetak" method="get">
				  <div class="form-group col-md-12">
					<label class="font-weight-bold">Mulai Dari Tanggal</label>
					<input autocomplete="off" type="date" name="tanggal_awal" required class="form-control"/>
				</div>
				<div class="form-group col-md-12">
					<label class="font-weight-bold">Sampai Tanggal</label>
					<input autocomplete="off" type="date" name="tanggal_akhir" required class="form-control"/>
				</div>
				<div class="form-group col-md-12">
					<label class="font-weight-bold">Penanggung Jawab</label>
					<input autocomplete="off" type="Text" name="penanggung_jawab" required class="form-control"/>
				</div>
				<div align="center">
				<input type="submit" class="btn btn-primary" ></td>
				</div>
				
				</form>
				
      </div>
	  			
      <div class="modal-footer">
	  
      </div>
    </div>
  </div>
</div>

<div class="card shadow mb-4">
    <!-- /.card-header -->
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-warning"><i class="fa fa-table"></i> Hasil Akhir Perankingan</h6>
    </div>

    <div class="card-body">
		<div class="table-responsive">
			<table class="table table-bordered" width="100%" cellspacing="0">
				<thead class="bg-warning text-white">
					<tr align="center">
						<th>Jenis Kain</th>
						<th>Keterangan</th>
						<th>Tanggal Penilaian</th>
						<th>Nilai Preferensi</th>
						<th width="15%">Ranking</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$no=1;
						foreach ($hasil as $keys): ?>
					<tr align="center">
						

						<td  style="padding-left: 5px;">
				
							<?php
							$nama_alternatif = $this->Perhitungan_model->get_hasil_alternatif($keys->id_alternatif);
							echo $nama_alternatif['nama'];
							?>

						</td>

						<td style="padding-left: 5px;">
						
							<?php
							$jurusan_alternatif = $this->Perhitungan_model->get_hasil_alternatif($keys->id_alternatif);
							echo $jurusan_alternatif['keterangan'];
							?>

						</td>

						<td style="padding-left: 5px;">
						
							<?php
							$jurusan_alternatif = $this->Perhitungan_model->get_hasil_alternatif($keys->id_alternatif);
							echo $jurusan_alternatif['tgl_penilaian'];
							?>

						</td>
						<td><?= $keys->nilai ?></td>
						<td><?= $no; ?></td>
					</tr>
					<?php
						$no++;
						endforeach ?>
				</tbody>
			</table>
		</div>
	</div>
</div>



<?php
$this->load->view('layouts/footer_admin');
?>