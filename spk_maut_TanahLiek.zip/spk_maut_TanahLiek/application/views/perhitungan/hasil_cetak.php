<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cetak laporan</title>
</head>
<body>

<?php
	$dt1 = $_GET["tanggal_awal"];
	$dt2 = $_GET["tanggal_akhir"];
	$penanggung_jawab = $_GET["penanggung_jawab"];
?>


<center>

<h3>Laporan Hasil Perhitungan Penentuan Kain Terbaik</h3>
<h3>Dalam Pembuatan Salendang Batik Tanah Liek</h3>
<h3>Dengan Menggunakan Metode Multi-Attribute Utility Theory (MAUT)</h3>

<p>Periode <?php echo $dt1?> Hingga <?php echo $dt2?> </p>

</center>
<?php
				$koneksi = mysqli_connect('localhost','root','','spk_maut_tanahliek') or die (mysqli_error());
				$sql = "SELECT * FROM hasil LEFT JOIN Alternatif ON hasil.id_alternatif = alternatif.id_alternatif";
				$query = mysqli_query($koneksi,$sql) or die (mysqli_error($koneksi));
				?>
	
		
	<br>	

	
	<?php


		
			

			$no = 1;

			$sql = "SELECT * FROM hasil LEFT JOIN alternatif ON hasil.id_alternatif = alternatif.id_alternatif WHERE tgl_penilaian BETWEEN '$dt1' AND '$dt2'
			ORDER BY nilai DESC";
			$query = mysqli_query($koneksi,$sql) or die (mysqli_error($koneksi));

			echo "<table border='1' class='table table-striped table-bordered' width='100%'>
					<thead>
						<tr align='center'>
							
							<th>Nama Kain</th>
							<th>Keterangan</th>
							<th>Tanggal Penilaian</th>
							<th>Nilai</th>
							<th>Rank</th>
						</tr>
					</thead>
					<tbody>";

					while($data1 = mysqli_fetch_array($query)){?>
						
						<tr align="center">
							
							<td><?php echo $data1['nama'];?></td>
							<td><?php echo $data1['keterangan'];?></td>
							<td><?php echo $data1['tgl_penilaian'];?></td>
							<td><?php echo $data1['nilai'];?></td>
							<td><?php echo $no;?></td>
						</tr>

						<?php $no++; ?>

					<?php }

			echo "	</tbody>
				  </table>";

		
			
	?>

<div align="right">
    <div>
	<p>Padang, <span id="tanggalwaktu"></span></p>
	<script>
	var tw = new Date();
	if (tw.getTimezoneOffset() == 0) (a=tw.getTime() + ( 7 *60*60*1000))
	else (a=tw.getTime());
	tw.setTime(a);
	var tahun= tw.getFullYear ();
	var hari= tw.getDay ();
	var bulan= tw.getMonth ();
	var tanggal= tw.getDate ();
	var hariarray=new Array("Minggu,","Senin,","Selasa,","Rabu,","Kamis,","Jum'at,","Sabtu,");
	var bulanarray=new Array("Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","Nopember","Desember");
	document.getElementById("tanggalwaktu").innerHTML = hariarray[hari]+" "+tanggal+" "+bulanarray[bulan]+" "+tahun;
	
	</script>
	</div>
	<br>
	<br>
	<br>
	
	<p>
		<u>(<?php echo $penanggung_jawab;?>)</u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</p>
 </div>

</body>
</html>

<table>
 <script>
 window.print()
 </script>
 </table>